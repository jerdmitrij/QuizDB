/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testingsystem;

/**
 * Class representing a system user.
 */
public class User {
    public String name;
    public String login;
    public String password;

    /**
     * Constructor for User.
     */
    public User(String name, String login, String password) {
        this.name = name;
        this.login = login;
        this.password = password;
    }

    /**
     * Method to check login credentials.
     */
    public boolean enter(String login, String password) {
        return this.login.equals(login) && this.password.equals(password);
    }
    
    
    static public String formatName(String name) {
        if (name == null || name.trim().isEmpty()) return "Viesis";
        return name;
        
    }
    
    
    
}
