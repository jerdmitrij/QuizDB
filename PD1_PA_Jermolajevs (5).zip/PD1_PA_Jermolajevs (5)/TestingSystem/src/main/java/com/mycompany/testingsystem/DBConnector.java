/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testingsystem;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Helper class to connect to the database.
 */
public class DBConnector {

    /**
     * Gets connection to the database.
     */
    public static Connection getConnection() throws SQLException {

        String url = "jdbc:derby://localhost:1527/QuizDB";
        String user = "dbuser";
        String pass = "dbuser"; 

        try {

            Class.forName("org.apache.derby.client.ClientAutoloadedDriver");
            return DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e.getMessage());
            return null;
        }
    }
}
