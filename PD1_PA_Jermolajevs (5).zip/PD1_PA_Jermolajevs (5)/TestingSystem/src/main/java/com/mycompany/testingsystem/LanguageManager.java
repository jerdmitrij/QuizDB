/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testingsystem;

/**
 * Placeholder class for language manager system logic.
 */
public class LanguageManager {
    // To be implemented

    static public String getLangSuffix(String lang) {

        if ("RU".equals(lang)) {
            return "_RU";
        } else if ("ENG".equals(lang)) {
            return "_EN";
        }
        return "";
    }
}
