package com.mycompany.testingsystem;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Dmitrijs.Jermolajevs
 */
public class UserTest {

    public UserTest() {
        
    }

    @Test
    public void testFormatName() {
        assertEquals("Viesis", User.formatName(""), "Empty name should return Viesis");
        assertEquals("Dmitrijs", User.formatName("Dmitrijs"), "Normal name should stay the same");
    }

    @Test
    public void testUserLogin() {
        User testUser = new User("Dima", "admin", "1234");
        assertTrue(testUser.enter("admin", "1234"), "Login should be successful");
        assertFalse(testUser.enter("admin", "wrong"), "Login should fail with wrong password");
    }
    
}
