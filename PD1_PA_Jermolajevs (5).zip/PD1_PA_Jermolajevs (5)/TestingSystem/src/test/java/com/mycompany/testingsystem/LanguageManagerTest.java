/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.testingsystem;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Dmitrijs.Jermolajevs
 */
public class LanguageManagerTest {

    public LanguageManagerTest() {

    }

    @Test
    public void testGetLangSuffix() {
        
        LanguageManager db = new LanguageManager();
        

        assertEquals("_RU", db.getLangSuffix("RU"), "Should return _RU for Russian");
        assertEquals("_EN", db.getLangSuffix("ENG"), "Should return _EN for English");
        assertEquals("", db.getLangSuffix("LV"), "Should return empty string for Latvian/Other");
    }
}