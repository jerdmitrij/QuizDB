package com.mycompany.testingsystem;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Dmitrijs.Jermolajevs
 */
public class QuestionTest {

    public QuestionTest() {

    }

    @Test
    public void testCalculatePercentage() {
        int result = Question.calculatePercentage(8, 10);
        assertEquals(80, result, "8 correct out of 10 should be 80%");
    }
}
