/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testingsystem;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBConnector {
    
    public static Connection getConnection() throws SQLException {
        Properties props = new Properties();
        // Fails config.properties jāatrodas projekta saknes mapē
        try (FileInputStream in = new FileInputStream("config.properties")) {
            props.load(in);
            
            String url = props.getProperty("db.url");
            String user = props.getProperty("db.user");
            String pass = props.getProperty("db.password");
            
            return DriverManager.getConnection(url, user, pass);
        } catch (IOException e) {
            System.out.println("Kļūda ielādējot config.properties: " + e.getMessage());
            return null;
        }
    }
}