/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testingsystem;

/**
 *
 * @author Dmitrijs.Jermolajevs
 */
public class User {
    protected String name;
    protected String login;
    protected String password;

    public User(String name, String login, String password) {
        this.name = name;
        this.login = login;
        this.password = password;
    }

    public boolean enter(String login, String password) {
        
        return this.login.equals(login) && this.password.equals(password);
    }
}
